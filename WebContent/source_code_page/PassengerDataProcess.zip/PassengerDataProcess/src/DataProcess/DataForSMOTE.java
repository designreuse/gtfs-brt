package DataProcess;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class DataForSMOTE {

	public static final int COLUMN_NUMBER = 8;
	public static final int ROW_NUMBER = 77225;

	public static final String MORNING = "1";
	public static final String NOON = "2";
	public static final String AFTERNOON = "3";
	public static final String EVENING = "4";

	public static final String WEEKDAY = "0";
	public static final String WEEKEND = "1";

	public static final String Direction_EAST = "0";
	public static final String Direction_WEST = "1";

	public static final String GOOD_WEATHER = "3";
	public static final String FAIR_WEATHER = "2";
	public static final String BAD_WEATHER = "1";

	public static final String ROUTE9 = "9";
	public static final String ROUTE10 = "10";
	public static final String ROUTE11 = "11";
	public static final String ROUTE12 = "12";
	public static final String ROUTE63 = "63";
	public static final String ROUTE90 = "90";

	public static void main(String[] args) throws Exception {
		String[][] Data = WeatherPassengerLink.getDataFromCSV(ROW_NUMBER,
				COLUMN_NUMBER, "SMOTE_Prepare.csv");

		BufferedWriter writer = new BufferedWriter(new FileWriter("Route12BroadwayEast.csv"));
		BufferedWriter writer1 = new BufferedWriter(new FileWriter("Route12BroadwayWest.csv"));
		BufferedWriter writer2= new BufferedWriter(new FileWriter("Route12GreyhoundEast.csv"));
		BufferedWriter writer3 = new BufferedWriter(new FileWriter("Route12GreyhoundWest.csv"));
	
// This Route 12 Washington Ave Broad Way, East Direction, Weekday, Morning, Good Weather Trips 
			writer.write("This Route 12 Washington Ave Broad Way East Direction  Weekday, Morning  Good Weather Trips \n ");

		for (int i = 1; i < ROW_NUMBER; i++) {
			String linePassengerOn = "";
			String linePassengerOff = "";
			if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
					&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(MORNING)
					&& Data[i][7].equals(GOOD_WEATHER)
					&& Data[i][2].equals("7175")
					&& Data[i + 42][2].equals("9018")) {
				
				for (int j = i; j < i + 42; j++) {
					linePassengerOn += Data[j][3] + ",";
					linePassengerOff += Data[j][4] + ",";
				}
				linePassengerOn += "\n";
				linePassengerOff += "\n";
			}
			writer.write(linePassengerOn);
			writer.write(linePassengerOff);
		}

		// This Route 12 Washington Ave Broad Way, East Direction, Weekday, Morning, fair Weather Trips 
							writer.write("This Route 12 Washington Ave Broad Way  East Direction  Weekday Morning  fair Weather Trips " +"\n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(MORNING)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 42][2].equals("9018")) {
						
						for (int j = i; j < i + 42; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer.write(linePassengerOn);
					writer.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, East Direction, Weekday, Morning, BAD Weather Trips 
							writer.write("This Route 12 Washington Ave Broad Way  East Direction  Weekday  Morning BAD Weather Trips " +"\n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(MORNING)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 42][2].equals("9018")) {
						
						for (int j = i; j < i + 42; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer.write(linePassengerOn);
					writer.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, East Direction, Weekday, Noon, Good Weather Trips 
	writer.write("This Route 12 Washington Ave Broad Way  East Direction  Weekday  Noon  Good Weather Trips  " +"\n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(NOON)
							&& Data[i][7].equals(GOOD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 42][2].equals("9018")) {
						
						for (int j = i; j < i + 42; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer.write(linePassengerOn);
					writer.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, East Direction, Weekday, NOON, FAIR Weather Trips 
							writer.write("This Route 12 Washington Ave Broad Way  East Direction  Weekday  NOON  FAIR Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(NOON)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 42][2].equals("9018")) {
						
						for (int j = i; j < i + 42; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer.write(linePassengerOn);
					writer.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, East Direction, Weekday, NOON, BAD Weather Trips
					writer.write(" This Route 12 Washington Ave Broad Way  East Direction  Weekday  NOON  BAD Weather Trips  \n ");
		
				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(NOON)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 42][2].equals("9018")) {
						
						for (int j = i; j < i + 42; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer.write(linePassengerOn);
					writer.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, East Direction, Weekday, AFTERNOON, Good Weather Trips 
							writer.write("This Route 12 Washington Ave Broad Way  East Direction  Weekday  AFTERNOON  Good Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(AFTERNOON)
							&& Data[i][7].equals(GOOD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 42][2].equals("9018")) {
						
						for (int j = i; j < i + 42; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer.write(linePassengerOn);
					writer.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, East Direction, Weekday, AFTERNOON, FAIR Weather Trips 
							writer.write("This Route 12 Washington Ave Broad Way  East Direction  Weekday  AFTERNOON  FAIR Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(AFTERNOON)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 42][2].equals("9018")) {
						
						for (int j = i; j < i + 42; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer.write(linePassengerOn);
					writer.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, East Direction, Weekday, AFTERNOON, BAD Weather Trips 
							writer.write("This Route 12 Washington Ave Broad Way  East Direction  Weekday  AFTERNOON BAD Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(AFTERNOON)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 42][2].equals("9018")) {
						
						for (int j = i; j < i + 42; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer.write(linePassengerOn);
					writer.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, East Direction, Weekday, EVENING, Good Weather Trips 
							writer.write("This Route 12 Washington Ave Broad Way  East Direction  Weekday  EVENING  Good Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(EVENING)
							&& Data[i][7].equals(GOOD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 42][2].equals("9018")) {
						
						for (int j = i; j < i + 42; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer.write(linePassengerOn);
					writer.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, East Direction, Weekday, EVENING, FAIR Weather Trips 
							writer.write("This Route 12 Washington Ave Broad Way  East Direction  Weekday  EVENING  FAIR Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(EVENING)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 42][2].equals("9018")) {
						
						for (int j = i; j < i + 42; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer.write(linePassengerOn);
					writer.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, East Direction, Weekday, EVENING, BAD Weather Trips 
								writer.write(" This Route 12 Washington Ave Broad Way East Direction  Weekday  EVENING  BAD Weather Trips \n");
	
				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(EVENING)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 42][2].equals("9018")) {
						
						for (int j = i; j < i + 42; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer.write(linePassengerOn);
					writer.write(linePassengerOff);
				}
				
		
						
// This Route 12 Washington Ave Broad Way, East Direction, WEEKEND, Morning, Good Weather Trips 
			writer.write("This Route 12 Washington Ave Broad Way  East Direction  WEEKEND  Morning  Good Weather Trips \n ");

		for (int i = 1; i < ROW_NUMBER; i++) {
			String linePassengerOn = "";
			String linePassengerOff = "";
			if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
					&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(MORNING)
					&& Data[i][7].equals(GOOD_WEATHER)
					&& Data[i][2].equals("7175")
					&& Data[i + 42][2].equals("9018")) {
				
				for (int j = i; j < i + 42; j++) {
					linePassengerOn += Data[j][3] + ",";
					linePassengerOff += Data[j][4] + ",";
				}
				linePassengerOn += "\n";
				linePassengerOff += "\n";
			}
			writer.write(linePassengerOn);
			writer.write(linePassengerOff);
		}

		// This Route 12 Washington Ave Broad Way, East Direction, WEEKEND, Morning, fair Weather Trips 
							writer.write("This Route 12 Washington Ave Broad Way  East Direction  WEEKEND  Morning  fair Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(MORNING)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 42][2].equals("9018")) {
						
						for (int j = i; j < i + 42; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer.write(linePassengerOn);
					writer.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, East Direction, WEEKEND, Morning, BAD Weather Trips 
							writer.write("This Route 12 Washington Ave Broad Way  East Direction  WEEKEND  Morning  BAD Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(MORNING)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 42][2].equals("9018")) {
						
						for (int j = i; j < i + 42; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer.write(linePassengerOn);
					writer.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, East Direction, WEEKEND, Noon, Good Weather Trips 
							writer.write("This Route 12 Washington Ave Broad Way  East Direction  WEEKEND Noon  Good Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(NOON)
							&& Data[i][7].equals(GOOD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 42][2].equals("9018")) {
						
						for (int j = i; j < i + 42; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer.write(linePassengerOn);
					writer.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, East Direction, WEEKEND, NOON, FAIR Weather Trips 
							writer.write("This Route 12 Washington Ave Broad Way  East Direction  WEEKEND  NOON  FAIR Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(NOON)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 42][2].equals("9018")) {
						
						for (int j = i; j < i + 42; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer.write(linePassengerOn);
					writer.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, East Direction, WEEKEND, NOON, BAD Weather Trips 
							writer.write("This Route 12 Washington Ave Broad Way East Direction  WEEKEND  NOON  BAD Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(NOON)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 42][2].equals("9018")) {
						
						for (int j = i; j < i + 42; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
 					writer.write(linePassengerOn);
					writer.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, East Direction, WEEKEND, AFTERNOON, Good Weather Trips 
							writer.write("This Route 12 Washington Ave Broad Way  East Direction  WEEKEND  AFTERNOON  Good Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(AFTERNOON)
							&& Data[i][7].equals(GOOD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 42][2].equals("9018")) {
						
						for (int j = i; j < i + 42; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer.write(linePassengerOn);
					writer.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, East Direction, WEEKEND, AFTERNOON, FAIR Weather Trips 
							writer.write("This Route 12 Washington Ave Broad Way  East Direction  WEEKEND  AFTERNOON  FAIR Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(AFTERNOON)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 42][2].equals("9018")) {
						
						for (int j = i; j < i + 42; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer.write(linePassengerOn);
					writer.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, East Direction, WEEKEND, AFTERNOON, BAD Weather Trips 
							writer.write("This Route 12 Washington Ave Broad Way  East Direction  WEEKEND  AFTERNOON  BAD Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(AFTERNOON)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 42][2].equals("9018")) {
						
						for (int j = i; j < i + 42; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer.write(linePassengerOn);
					writer.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, East Direction, WEEKEND, EVENING, Good Weather Trips 
							writer.write(" This Route 12 Washington Ave Broad Way  East Direction  WEEKEND  EVENING  Good Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(EVENING)
							&& Data[i][7].equals(GOOD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 42][2].equals("9018")) {
						
						for (int j = i; j < i + 42; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer.write(linePassengerOn);
					writer.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, East Direction, WEEKEND, EVENING, FAIR Weather Trips 
							writer.write("This Route 12 Washington Ave Broad Way  East Direction  WEEKEND  EVENING  FAIR Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(EVENING)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 42][2].equals("9018")) {
						

						for (int j = i; j < i + 42; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer.write(linePassengerOn);
					writer.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, East Direction, WEEKEND, EVENING, BAD Weather Trips 
	     writer.write(" This Route 12 Washington Ave Broad Way  East Direction  WEEKEND  EVENING  BAD Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(EVENING)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 42][2].equals("9018")) {
						
						for (int j = i; j < i + 42; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer.write(linePassengerOn);
					writer.write(linePassengerOff);
				}
				
				
				
		writer.close();
		
		// This Route 12 Washington Ave Broad Way, WEST Direction, Weekday, Morning, Good Weather Trips 
			writer1.write("This Route 12 Washington Ave Broad Way WEST Direction  Weekday, Morning  Good Weather Trips \n ");

		for (int i = 1; i < ROW_NUMBER; i++) {
			String linePassengerOn = "";
			String linePassengerOff = "";
			if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
					&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(MORNING)
					&& Data[i][7].equals(GOOD_WEATHER)
					&& Data[i][2].equals("9018")
					&& Data[i + 47][2].equals("7175")) {
				
				for (int j = i; j < i + 47; j++) {
					linePassengerOn += Data[j][3] + ",";
					linePassengerOff += Data[j][4] + ",";
				}
				linePassengerOn += "\n";
				linePassengerOff += "\n";
			}
			writer1.write(linePassengerOn);
			writer1.write(linePassengerOff);
		}

		// This Route 12 Washington Ave Broad Way, WEST Direction, Weekday, Morning, fair Weather Trips 
							writer1.write("This Route 12 Washington Ave Broad Way  WEST Direction  Weekday Morning  fair Weather Trips " +"\n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(MORNING)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("9018")
							&& Data[i + 47][2].equals("7175")) {
						
						for (int j = i; j < i + 47; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer1.write(linePassengerOn);
					writer1.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, WEST Direction, Weekday, Morning, BAD Weather Trips 
							writer1.write("This Route 12 Washington Ave Broad Way  WEST Direction  Weekday  Morning BAD Weather Trips " +"\n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(MORNING)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("9018")
							&& Data[i + 47][2].equals("7175")) {
						
						for (int j = i; j < i + 47; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer1.write(linePassengerOn);
					writer1.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, WEST Direction, Weekday, Noon, Good Weather Trips 
	writer1.write("This Route 12 Washington Ave Broad Way  WEST Direction  Weekday  Noon  Good Weather Trips  " +"\n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(NOON)
							&& Data[i][7].equals(GOOD_WEATHER)
							&& Data[i][2].equals("9018")
							&& Data[i + 47][2].equals("7175")) {
						
						for (int j = i; j < i + 47; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer1.write(linePassengerOn);
					writer1.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, WEST Direction, Weekday, NOON, FAIR Weather Trips 
							writer1.write("This Route 12 Washington Ave Broad Way  WEST Direction  Weekday  NOON  FAIR Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(NOON)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("9018")
							&& Data[i + 47][2].equals("7175")) {
						
						for (int j = i; j < i + 47; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer1.write(linePassengerOn);
					writer1.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, WEST Direction, Weekday, NOON, BAD Weather Trips
					writer1.write(" This Route 12 Washington Ave Broad Way  WEST Direction  Weekday  NOON  BAD Weather Trips  \n ");
		
				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(NOON)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("9018")
							&& Data[i + 47][2].equals("7175")) {
						
						for (int j = i; j < i + 47; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer1.write(linePassengerOn);
					writer1.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, WEST Direction, Weekday, AFTERNOON, Good Weather Trips 
							writer1.write("This Route 12 Washington Ave Broad Way  WEST Direction  Weekday  AFTERNOON  Good Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(AFTERNOON)
							&& Data[i][7].equals(GOOD_WEATHER)
							&& Data[i][2].equals("9018")
							&& Data[i + 47][2].equals("7175")) {
						
						for (int j = i; j < i + 47; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer1.write(linePassengerOn);
					writer1.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, WEST Direction, Weekday, AFTERNOON, FAIR Weather Trips 
							writer1.write("This Route 12 Washington Ave Broad Way  WEST Direction  Weekday  AFTERNOON  FAIR Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(AFTERNOON)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("9018")
							&& Data[i + 47][2].equals("7175")) {
						
						for (int j = i; j < i + 47; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer1.write(linePassengerOn);
					writer1.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, WEST Direction, Weekday, AFTERNOON, BAD Weather Trips 
							writer1.write("This Route 12 Washington Ave Broad Way  WEST Direction  Weekday  AFTERNOON BAD Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(AFTERNOON)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("9018")
							&& Data[i + 47][2].equals("7175")) {
						
						for (int j = i; j < i + 47; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer1.write(linePassengerOn);
					writer1.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, WEST Direction, Weekday, EVENING, Good Weather Trips 
							writer1.write("This Route 12 Washington Ave Broad Way  WEST Direction  Weekday  EVENING  Good Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(EVENING)
							&& Data[i][7].equals(GOOD_WEATHER)
							&& Data[i][2].equals("9018")
							&& Data[i + 47][2].equals("7175")) {
						
						for (int j = i; j < i + 47; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer1.write(linePassengerOn);
					writer1.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, WEST Direction, Weekday, EVENING, FAIR Weather Trips 
							writer1.write("This Route 12 Washington Ave Broad Way  WEST Direction  Weekday  EVENING  FAIR Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(EVENING)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("9018")
							&& Data[i + 47][2].equals("7175")) {
						
						for (int j = i; j < i + 47; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer1.write(linePassengerOn);
					writer1.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, WEST Direction, Weekday, EVENING, BAD Weather Trips 
								writer1.write(" This Route 12 Washington Ave Broad Way WEST Direction  Weekday  EVENING  BAD Weather Trips \n");
	
				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(EVENING)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("9018")
							&& Data[i + 47][2].equals("7175")) {
						
						for (int j = i; j < i + 47; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer1.write(linePassengerOn);
					writer1.write(linePassengerOff);
				}
				
		
						
// This Route 12 Washington Ave Broad Way, WEST Direction, WEEKEND, Morning, Good Weather Trips 
			writer1.write("This Route 12 Washington Ave Broad Way  WEST Direction  WEEKEND  Morning  Good Weather Trips \n ");

		for (int i = 1; i < ROW_NUMBER; i++) {
			String linePassengerOn = "";
			String linePassengerOff = "";
			if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
					&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(MORNING)
					&& Data[i][7].equals(GOOD_WEATHER)
					&& Data[i][2].equals("9018")
					&& Data[i + 47][2].equals("7175")) {
				
				for (int j = i; j < i + 47; j++) {
					linePassengerOn += Data[j][3] + ",";
					linePassengerOff += Data[j][4] + ",";
				}
				linePassengerOn += "\n";
				linePassengerOff += "\n";
			}
			writer1.write(linePassengerOn);
			writer1.write(linePassengerOff);
		}

		// This Route 12 Washington Ave Broad Way, WEST Direction, WEEKEND, Morning, fair Weather Trips 
							writer1.write("This Route 12 Washington Ave Broad Way  WEST Direction  WEEKEND  Morning  fair Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(MORNING)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("9018")
							&& Data[i + 47][2].equals("7175")) {
						
						for (int j = i; j < i + 47; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer1.write(linePassengerOn);
					writer1.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, WEST Direction, WEEKEND, Morning, BAD Weather Trips 
							writer1.write("This Route 12 Washington Ave Broad Way  WEST Direction  WEEKEND  Morning  BAD Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(MORNING)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("9018")
							&& Data[i + 47][2].equals("7175")) {
						
						for (int j = i; j < i + 47; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer1.write(linePassengerOn);
					writer1.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, WEST Direction, WEEKEND, Noon, Good Weather Trips 
							writer1.write("This Route 12 Washington Ave Broad Way  WEST Direction  WEEKEND Noon  Good Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(NOON)
							&& Data[i][7].equals(GOOD_WEATHER)
							&& Data[i][2].equals("9018")
							&& Data[i + 47][2].equals("7175")) {
						
						for (int j = i; j < i + 47; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer1.write(linePassengerOn);
					writer1.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, WEST Direction, WEEKEND, NOON, FAIR Weather Trips 
							writer1.write("This Route 12 Washington Ave Broad Way  WEST Direction  WEEKEND  NOON  FAIR Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(NOON)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("9018")
							&& Data[i + 47][2].equals("7175")) {
						
						for (int j = i; j < i + 47; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer1.write(linePassengerOn);
					writer1.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, WEST Direction, WEEKEND, NOON, BAD Weather Trips 
							writer1.write("This Route 12 Washington Ave Broad Way WEST Direction  WEEKEND  NOON  BAD Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(NOON)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("9018")
							&& Data[i + 47][2].equals("7175")) {
						
						for (int j = i; j < i + 47; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
 					writer1.write(linePassengerOn);
					writer1.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, WEST Direction, WEEKEND, AFTERNOON, Good Weather Trips 
							writer1.write("This Route 12 Washington Ave Broad Way  WEST Direction  WEEKEND  AFTERNOON  Good Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(AFTERNOON)
							&& Data[i][7].equals(GOOD_WEATHER)
							&& Data[i][2].equals("9018")
							&& Data[i + 47][2].equals("7175")) {
						
						for (int j = i; j < i + 47; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer1.write(linePassengerOn);
					writer1.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, WEST Direction, WEEKEND, AFTERNOON, FAIR Weather Trips 
							writer1.write("This Route 12 Washington Ave Broad Way  WEST Direction  WEEKEND  AFTERNOON  FAIR Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(AFTERNOON)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("9018")
							&& Data[i + 47][2].equals("7175")) {
						
						for (int j = i; j < i + 47; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer1.write(linePassengerOn);
					writer1.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, WEST Direction, WEEKEND, AFTERNOON, BAD Weather Trips 
							writer1.write("This Route 12 Washington Ave Broad Way  WEST Direction  WEEKEND  AFTERNOON  BAD Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(AFTERNOON)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("9018")
							&& Data[i + 47][2].equals("7175")) {
						
						for (int j = i; j < i + 47; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer1.write(linePassengerOn);
					writer1.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, WEST Direction, WEEKEND, EVENING, Good Weather Trips 
							writer1.write(" This Route 12 Washington Ave Broad Way  WEST Direction  WEEKEND  EVENING  Good Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(EVENING)
							&& Data[i][7].equals(GOOD_WEATHER)
							&& Data[i][2].equals("9018")
							&& Data[i + 47][2].equals("7175")) {
						
						for (int j = i; j < i + 47; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer1.write(linePassengerOn);
					writer1.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, WEST Direction, WEEKEND, EVENING, FAIR Weather Trips 
							writer1.write("This Route 12 Washington Ave Broad Way  WEST Direction  WEEKEND  EVENING  FAIR Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(EVENING)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("9018")
							&& Data[i + 47][2].equals("7175")) {
						

						for (int j = i; j < i + 47; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer1.write(linePassengerOn);
					writer1.write(linePassengerOff);
				}
				
		// This Route 12 Washington Ave Broad Way, WEST Direction, WEEKEND, EVENING, BAD Weather Trips 
	     writer1.write(" This Route 12 Washington Ave Broad Way  WEST Direction  WEEKEND  EVENING  BAD Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(EVENING)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("9018")
							&& Data[i + 47][2].equals("7175")) {
						
						for (int j = i; j < i + 47; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer1.write(linePassengerOn);
					writer1.write(linePassengerOff);
				}
				
				
				
		writer1.close();
		
		
// This Route 12 Greyhound, EAST Direction, Weekday, Morning, Good Weather Trips 
			writer2.write("This Route 12 Greyhound EAST Direction  Weekday, Morning  Good Weather Trips \n ");

		for (int i = 1; i < ROW_NUMBER; i++) {
			String linePassengerOn = "";
			String linePassengerOff = "";
			if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
					&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(MORNING)
					&& Data[i][7].equals(GOOD_WEATHER)
					&& Data[i][2].equals("7175")
					&& Data[i + 43][2].equals("10503")) {
				
				for (int j = i; j < i + 43; j++) {
					linePassengerOn += Data[j][3] + ",";
					linePassengerOff += Data[j][4] + ",";
				}
				linePassengerOn += "\n";
				linePassengerOff += "\n";
			}
			writer2.write(linePassengerOn);
			writer2.write(linePassengerOff);
		}

		// This Route 12 Greyhound, EAST Direction, Weekday, Morning, fair Weather Trips 
							writer2.write("This Route 12 Greyhound  EAST Direction  Weekday Morning  fair Weather Trips " +"\n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(MORNING)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 43][2].equals("10503")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer2.write(linePassengerOn);
					writer2.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, EAST Direction, Weekday, Morning, BAD Weather Trips 
							writer2.write("This Route 12 Greyhound  EAST Direction  Weekday  Morning BAD Weather Trips " +"\n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(MORNING)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 43][2].equals("10503")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer2.write(linePassengerOn);
					writer2.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, EAST Direction, Weekday, Noon, Good Weather Trips 
	writer2.write("This Route 12 Greyhound  EAST Direction  Weekday  Noon  Good Weather Trips  " +"\n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(NOON)
							&& Data[i][7].equals(GOOD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 43][2].equals("10503")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer2.write(linePassengerOn);
					writer2.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, EAST Direction, Weekday, NOON, FAIR Weather Trips 
							writer2.write("This Route 12 Greyhound  EAST Direction  Weekday  NOON  FAIR Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(NOON)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 43][2].equals("10503")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer2.write(linePassengerOn);
					writer2.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, EAST Direction, Weekday, NOON, BAD Weather Trips
					writer2.write(" This Route 12 Greyhound  EAST Direction  Weekday  NOON  BAD Weather Trips  \n ");
		
				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(NOON)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 43][2].equals("10503")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer2.write(linePassengerOn);
					writer2.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, EAST Direction, Weekday, AFTERNOON, Good Weather Trips 
							writer2.write("This Route 12 Greyhound  EAST Direction  Weekday  AFTERNOON  Good Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(AFTERNOON)
							&& Data[i][7].equals(GOOD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 43][2].equals("10503")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer2.write(linePassengerOn);
					writer2.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, EAST Direction, Weekday, AFTERNOON, FAIR Weather Trips 
							writer2.write("This Route 12 Greyhound  EAST Direction  Weekday  AFTERNOON  FAIR Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(AFTERNOON)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 43][2].equals("10503")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer2.write(linePassengerOn);
					writer2.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, EAST Direction, Weekday, AFTERNOON, BAD Weather Trips 
							writer2.write("This Route 12 Greyhound  EAST Direction  Weekday  AFTERNOON BAD Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(AFTERNOON)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 43][2].equals("10503")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer2.write(linePassengerOn);
					writer2.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, EAST Direction, Weekday, EVENING, Good Weather Trips 
							writer2.write("This Route 12 Greyhound  EAST Direction  Weekday  EVENING  Good Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(EVENING)
							&& Data[i][7].equals(GOOD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 43][2].equals("10503")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer2.write(linePassengerOn);
					writer2.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, EAST Direction, Weekday, EVENING, FAIR Weather Trips 
							writer2.write("This Route 12 Greyhound  EAST Direction  Weekday  EVENING  FAIR Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(EVENING)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 43][2].equals("10503")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer2.write(linePassengerOn);
					writer2.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, EAST Direction, Weekday, EVENING, BAD Weather Trips 
								writer2.write(" This Route 12 Greyhound EAST Direction  Weekday  EVENING  BAD Weather Trips \n");
	
				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(EVENING)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 43][2].equals("10503")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer2.write(linePassengerOn);
					writer2.write(linePassengerOff);
				}
				
		
						
// This Route 12 Greyhound, EAST Direction, WEEKEND, Morning, Good Weather Trips 
			writer2.write("This Route 12 Greyhound  EAST Direction  WEEKEND  Morning  Good Weather Trips \n ");

		for (int i = 1; i < ROW_NUMBER; i++) {
			String linePassengerOn = "";
			String linePassengerOff = "";
			if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
					&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(MORNING)
					&& Data[i][7].equals(GOOD_WEATHER)
					&& Data[i][2].equals("7175")
					&& Data[i + 43][2].equals("10503")) {
				
				for (int j = i; j < i + 43; j++) {
					linePassengerOn += Data[j][3] + ",";
					linePassengerOff += Data[j][4] + ",";
				}
				linePassengerOn += "\n";
				linePassengerOff += "\n";
			}
			writer2.write(linePassengerOn);
			writer2.write(linePassengerOff);
		}

		// This Route 12 Greyhound, EAST Direction, WEEKEND, Morning, fair Weather Trips 
							writer2.write("This Route 12 Greyhound  EAST Direction  WEEKEND  Morning  fair Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(MORNING)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 43][2].equals("10503")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer2.write(linePassengerOn);
					writer2.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, EAST Direction, WEEKEND, Morning, BAD Weather Trips 
							writer2.write("This Route 12 Greyhound  EAST Direction  WEEKEND  Morning  BAD Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(MORNING)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 43][2].equals("10503")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer2.write(linePassengerOn);
					writer2.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, EAST Direction, WEEKEND, Noon, Good Weather Trips 
							writer2.write("This Route 12 Greyhound  EAST Direction  WEEKEND Noon  Good Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(NOON)
							&& Data[i][7].equals(GOOD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 43][2].equals("10503")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer2.write(linePassengerOn);
					writer2.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, EAST Direction, WEEKEND, NOON, FAIR Weather Trips 
							writer2.write("This Route 12 Greyhound  EAST Direction  WEEKEND  NOON  FAIR Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(NOON)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 43][2].equals("10503")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer2.write(linePassengerOn);
					writer2.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, EAST Direction, WEEKEND, NOON, BAD Weather Trips 
							writer2.write("This Route 12 Greyhound EAST Direction  WEEKEND  NOON  BAD Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(NOON)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 43][2].equals("10503")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
 					writer2.write(linePassengerOn);
					writer2.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, EAST Direction, WEEKEND, AFTERNOON, Good Weather Trips 
							writer2.write("This Route 12 Greyhound  EAST Direction  WEEKEND  AFTERNOON  Good Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(AFTERNOON)
							&& Data[i][7].equals(GOOD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 43][2].equals("10503")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer2.write(linePassengerOn);
					writer2.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, EAST Direction, WEEKEND, AFTERNOON, FAIR Weather Trips 
							writer2.write("This Route 12 Greyhound  EAST Direction  WEEKEND  AFTERNOON  FAIR Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(AFTERNOON)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 43][2].equals("10503")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer2.write(linePassengerOn);
					writer2.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, EAST Direction, WEEKEND, AFTERNOON, BAD Weather Trips 
							writer2.write("This Route 12 Greyhound  EAST Direction  WEEKEND  AFTERNOON  BAD Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(AFTERNOON)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 43][2].equals("10503")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer2.write(linePassengerOn);
					writer2.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, EAST Direction, WEEKEND, EVENING, Good Weather Trips 
							writer2.write(" This Route 12 Greyhound  EAST Direction  WEEKEND  EVENING  Good Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(EVENING)
							&& Data[i][7].equals(GOOD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 43][2].equals("10503")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer2.write(linePassengerOn);
					writer2.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, EAST Direction, WEEKEND, EVENING, FAIR Weather Trips 
							writer2.write("This Route 12 Greyhound  EAST Direction  WEEKEND  EVENING  FAIR Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(EVENING)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 43][2].equals("10503")) {
						

						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer2.write(linePassengerOn);
					writer2.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, EAST Direction, WEEKEND, EVENING, BAD Weather Trips 
	     writer2.write(" This Route 12 Greyhound  EAST Direction  WEEKEND  EVENING  BAD Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_EAST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(EVENING)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("7175")
							&& Data[i + 43][2].equals("10503")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer2.write(linePassengerOn);
					writer2.write(linePassengerOff);
				}
				
				
				
		writer2.close();


		
// This Route 12 Greyhound, WEST Direction, Weekday, Morning, Good Weather Trips 
			writer3.write("This Route 12 Greyhound WEST Direction  Weekday, Morning  Good Weather Trips \n ");

		for (int i = 1; i < ROW_NUMBER; i++) {
			String linePassengerOn = "";
			String linePassengerOff = "";
			if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
					&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(MORNING)
					&& Data[i][7].equals(GOOD_WEATHER)
					&& Data[i][2].equals("10503")
					&& Data[i + 43][2].equals("7175")) {
				
				for (int j = i; j < i + 43; j++) {
					linePassengerOn += Data[j][3] + ",";
					linePassengerOff += Data[j][4] + ",";
				}
				linePassengerOn += "\n";
				linePassengerOff += "\n";
			}
			writer3.write(linePassengerOn);
			writer3.write(linePassengerOff);
		}

		// This Route 12 Greyhound, WEST Direction, Weekday, Morning, fair Weather Trips 
							writer3.write("This Route 12 Greyhound  WEST Direction  Weekday Morning  fair Weather Trips " +"\n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(MORNING)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("10503")
							&& Data[i + 43][2].equals("7175")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer3.write(linePassengerOn);
					writer3.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, WEST Direction, Weekday, Morning, BAD Weather Trips 
							writer3.write("This Route 12 Greyhound  WEST Direction  Weekday  Morning BAD Weather Trips " +"\n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(MORNING)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("10503")
							&& Data[i + 43][2].equals("7175")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer3.write(linePassengerOn);
					writer3.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, WEST Direction, Weekday, Noon, Good Weather Trips 
	writer3.write("This Route 12 Greyhound  WEST Direction  Weekday  Noon  Good Weather Trips  " +"\n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(NOON)
							&& Data[i][7].equals(GOOD_WEATHER)
							&& Data[i][2].equals("10503")
							&& Data[i + 43][2].equals("7175")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer3.write(linePassengerOn);
					writer3.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, WEST Direction, Weekday, NOON, FAIR Weather Trips 
							writer3.write("This Route 12 Greyhound  WEST Direction  Weekday  NOON  FAIR Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(NOON)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("10503")
							&& Data[i + 43][2].equals("7175")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer3.write(linePassengerOn);
					writer3.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, WEST Direction, Weekday, NOON, BAD Weather Trips
					writer3.write(" This Route 12 Greyhound  WEST Direction  Weekday  NOON  BAD Weather Trips  \n ");
		
				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(NOON)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("10503")
							&& Data[i + 43][2].equals("7175")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer3.write(linePassengerOn);
					writer3.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, WEST Direction, Weekday, AFTERNOON, Good Weather Trips 
							writer3.write("This Route 12 Greyhound  WEST Direction  Weekday  AFTERNOON  Good Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(AFTERNOON)
							&& Data[i][7].equals(GOOD_WEATHER)
							&& Data[i][2].equals("10503")
							&& Data[i + 43][2].equals("7175")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer3.write(linePassengerOn);
					writer3.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, WEST Direction, Weekday, AFTERNOON, FAIR Weather Trips 
							writer3.write("This Route 12 Greyhound  WEST Direction  Weekday  AFTERNOON  FAIR Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(AFTERNOON)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("10503")
							&& Data[i + 43][2].equals("7175")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer3.write(linePassengerOn);
					writer3.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, WEST Direction, Weekday, AFTERNOON, BAD Weather Trips 
							writer3.write("This Route 12 Greyhound  WEST Direction  Weekday  AFTERNOON BAD Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(AFTERNOON)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("10503")
							&& Data[i + 43][2].equals("7175")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer3.write(linePassengerOn);
					writer3.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, WEST Direction, Weekday, EVENING, Good Weather Trips 
							writer3.write("This Route 12 Greyhound  WEST Direction  Weekday  EVENING  Good Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(EVENING)
							&& Data[i][7].equals(GOOD_WEATHER)
							&& Data[i][2].equals("10503")
							&& Data[i + 43][2].equals("7175")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer3.write(linePassengerOn);
					writer3.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, WEST Direction, Weekday, EVENING, FAIR Weather Trips 
							writer3.write("This Route 12 Greyhound  WEST Direction  Weekday  EVENING  FAIR Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(EVENING)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("10503")
							&& Data[i + 43][2].equals("7175")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer3.write(linePassengerOn);
					writer3.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, WEST Direction, Weekday, EVENING, BAD Weather Trips 
								writer3.write(" This Route 12 Greyhound WEST Direction  Weekday  EVENING  BAD Weather Trips \n");
	
				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKDAY) && Data[i][6].equals(EVENING)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("10503")
							&& Data[i + 43][2].equals("7175")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer3.write(linePassengerOn);
					writer3.write(linePassengerOff);
				}
				
		
						
// This Route 12 Greyhound, WEST Direction, WEEKEND, Morning, Good Weather Trips 
			writer3.write("This Route 12 Greyhound  WEST Direction  WEEKEND  Morning  Good Weather Trips \n ");

		for (int i = 1; i < ROW_NUMBER; i++) {
			String linePassengerOn = "";
			String linePassengerOff = "";
			if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
					&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(MORNING)
					&& Data[i][7].equals(GOOD_WEATHER)
					&& Data[i][2].equals("10503")
					&& Data[i + 43][2].equals("7175")) {
				
				for (int j = i; j < i + 43; j++) {
					linePassengerOn += Data[j][3] + ",";
					linePassengerOff += Data[j][4] + ",";
				}
				linePassengerOn += "\n";
				linePassengerOff += "\n";
			}
			writer3.write(linePassengerOn);
			writer3.write(linePassengerOff);
		}

		// This Route 12 Greyhound, WEST Direction, WEEKEND, Morning, fair Weather Trips 
							writer3.write("This Route 12 Greyhound  WEST Direction  WEEKEND  Morning  fair Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(MORNING)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("10503")
							&& Data[i + 43][2].equals("7175")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer3.write(linePassengerOn);
					writer3.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, WEST Direction, WEEKEND, Morning, BAD Weather Trips 
							writer3.write("This Route 12 Greyhound  WEST Direction  WEEKEND  Morning  BAD Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(MORNING)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("10503")
							&& Data[i + 43][2].equals("7175")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer3.write(linePassengerOn);
					writer3.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, WEST Direction, WEEKEND, Noon, Good Weather Trips 
							writer3.write("This Route 12 Greyhound  WEST Direction  WEEKEND Noon  Good Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(NOON)
							&& Data[i][7].equals(GOOD_WEATHER)
							&& Data[i][2].equals("10503")
							&& Data[i + 43][2].equals("7175")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer3.write(linePassengerOn);
					writer3.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, WEST Direction, WEEKEND, NOON, FAIR Weather Trips 
							writer3.write("This Route 12 Greyhound  WEST Direction  WEEKEND  NOON  FAIR Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(NOON)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("10503")
							&& Data[i + 43][2].equals("7175")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer3.write(linePassengerOn);
					writer3.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, WEST Direction, WEEKEND, NOON, BAD Weather Trips 
							writer3.write("This Route 12 Greyhound WEST Direction  WEEKEND  NOON  BAD Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(NOON)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("10503")
							&& Data[i + 43][2].equals("7175")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
 					writer3.write(linePassengerOn);
					writer3.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, WEST Direction, WEEKEND, AFTERNOON, Good Weather Trips 
							writer3.write("This Route 12 Greyhound  WEST Direction  WEEKEND  AFTERNOON  Good Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(AFTERNOON)
							&& Data[i][7].equals(GOOD_WEATHER)
							&& Data[i][2].equals("10503")
							&& Data[i + 43][2].equals("7175")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer3.write(linePassengerOn);
					writer3.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, WEST Direction, WEEKEND, AFTERNOON, FAIR Weather Trips 
							writer3.write("This Route 12 Greyhound  WEST Direction  WEEKEND  AFTERNOON  FAIR Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(AFTERNOON)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("10503")
							&& Data[i + 43][2].equals("7175")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer3.write(linePassengerOn);
					writer3.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, WEST Direction, WEEKEND, AFTERNOON, BAD Weather Trips 
							writer3.write("This Route 12 Greyhound  WEST Direction  WEEKEND  AFTERNOON  BAD Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(AFTERNOON)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("10503")
							&& Data[i + 43][2].equals("7175")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer3.write(linePassengerOn);
					writer3.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, WEST Direction, WEEKEND, EVENING, Good Weather Trips 
							writer3.write(" This Route 12 Greyhound  WEST Direction  WEEKEND  EVENING  Good Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(EVENING)
							&& Data[i][7].equals(GOOD_WEATHER)
							&& Data[i][2].equals("10503")
							&& Data[i + 43][2].equals("7175")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer3.write(linePassengerOn);
					writer3.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, WEST Direction, WEEKEND, EVENING, FAIR Weather Trips 
							writer3.write("This Route 12 Greyhound  WEST Direction  WEEKEND  EVENING  FAIR Weather Trips \n ");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(EVENING)
							&& Data[i][7].equals(FAIR_WEATHER)
							&& Data[i][2].equals("10503")
							&& Data[i + 43][2].equals("7175")) {
						

						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer3.write(linePassengerOn);
					writer3.write(linePassengerOff);
				}
				
		// This Route 12 Greyhound, WEST Direction, WEEKEND, EVENING, BAD Weather Trips 
	     writer3.write(" This Route 12 Greyhound  WEST Direction  WEEKEND  EVENING  BAD Weather Trips \n");

				for (int i = 1; i < ROW_NUMBER; i++) {
					String linePassengerOn = "";
					String linePassengerOff = "";
					if (Data[i][0].equals(ROUTE12) && Data[i][1].equals(Direction_WEST)
							&& Data[i][5].equals(WEEKEND) && Data[i][6].equals(EVENING)
							&& Data[i][7].equals(BAD_WEATHER)
							&& Data[i][2].equals("10503")
							&& Data[i + 43][2].equals("7175")) {
						
						for (int j = i; j < i + 43; j++) {
							linePassengerOn += Data[j][3] + ",";
							linePassengerOff += Data[j][4] + ",";
						}
						linePassengerOn += "\n";
						linePassengerOff += "\n";
					}
					writer3.write(linePassengerOn);
					writer3.write(linePassengerOff);
				}
				
				
				
		writer3.close();







	}
}
